#include <stdio.h>
int main()
{
char a;
printf("\n Enter a letter - ");
scanf("%c",&a);
printf("\n The letter that you entered is %c",a);
return 0;
}