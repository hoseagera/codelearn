#include <stdio.h>
int main()
{
    printf("\n -----------------------------------");
    printf("\n| Name      -  V Nani Kalyan        |");
    printf("\n| Education -  M tech , Mdiv        |");
    printf("\n| Church    -  capstone hyderabad   |");
    printf("\n| Kids      -  1                    |");
    printf("\n| Favorite verse  -  Proverbs 16:03 |");
    printf("\n -----------------------------------");
    
    printf("\n ------------------------------------");
    printf("\n| Name        -  Capstone church     |");
    printf("\n| Strength    -  700                 |");
    printf("\n| Men         -  300                 |");
    printf("\n| Women       -  300                 |");
    printf("\n| Kids        -  100                 |");
    printf("\n| Lead Pastor -  Chaitanya Gera      |");
    printf("\n ------------------------------------");
    
    printf("\n ------------------------------------");
    printf("\n| Name        -  Capstone Narsingi   |");
    printf("\n| Strength    -  60                  |");
    printf("\n| Men         -  25                  |");
    printf("\n| Women       -  25                  |");
    printf("\n| Kids        -  10                  |");
    printf("\n| Lead Pastor -  Nani Kalyan         |");
    printf("\n ------------------------------------");
c