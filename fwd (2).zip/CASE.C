#include <stdio.h>
int main()
{
    char x;
    printf("\n Enter the letter - ");
    scanf("%c", &x);
switch(x)
{
    case 'a':

    case 'e':
    
    case 'i':

    case 'o':
     
    case 'u':printf("\n It is a vowel");
     break;

     default : printf("\n It is a consonant");
     break;
}

return 0;
}