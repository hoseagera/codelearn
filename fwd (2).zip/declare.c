#include <stdio.h>
int main()
{
    int a=5;
    char b='a';
    float c=10;
    double d=20;
    printf("\n The value of a = %d",a);
    printf("\n The value of b = %c",b);
    printf("\n The value of c = %f",c);
    printf("\n The value of d = %f",d);
    return 0;
}