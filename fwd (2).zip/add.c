#include <stdio.h>
int main()
{
int a = 7;
int b = 8;
int c = a+b;
printf("sum of %d and %d = %d",a,b,c);
return 0;
}