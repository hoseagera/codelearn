#include <stdio.h>
int main()
{
    printf("\n ------------------------------------");
    printf("\n| Name        -  Capstone Narsingi   |");
    printf("\n| Strength    -  60                  |");
    printf("\n| Men         -  25                  |");
    printf("\n| Women       -  25                  |");
    printf("\n| Kids        -  10                  |");
    printf("\n| Lead Pastor -  Nani Kalyan         |");
    printf("\n ------------------------------------");
    return 0;
}