#include <stdio.h>
int main ()
{
printf("\n Name : hosea gera"); 
printf("\n Class : 11th ");
printf("\n Address : Green Space");
printf("\n \t   Hillaprk");
printf("\n \t   narsingi");
return 0;
}