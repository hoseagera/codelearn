#include <stdio.h>
int main()
{
    printf("\n ------------------------------------");
    printf("\n| Name        -  Capstone church     |");
    printf("\n| Strength    -  700                 |");
    printf("\n| Men         -  300                 |");
    printf("\n| Women       -  300                 |");
    printf("\n| Kids        -  100                 |");
    printf("\n| Lead Pastor -  Chaitanya Gera      |");
    printf("\n ------------------------------------");
    return 0;
}
    