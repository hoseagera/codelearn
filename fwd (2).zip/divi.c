#include <stdio.h>
int main()
{
int a = 10;
int b = 2;
int c = a/b;
printf("%d is the result of dividing %d by %d",c,a,b);
return 0;
}