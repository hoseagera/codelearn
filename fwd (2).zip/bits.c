#include <stdio.h>
int main()
{  
    printf("\n %d",sizeof(int));
    printf("\n %d",sizeof(char));
    printf("\n %d",sizeof(double));
    printf("\n %d",sizeof(float));
    return 0;
}