#include <stdio.h>
int main()
{
    int a;
    printf("\n Enter a number ");
    scanf("%d",&a);
if(a!=7)
{
    printf("\nThe number you have entered is 7");
}
else
{
    printf("\nThe number you have entered is not 7");
}
return 0;
}