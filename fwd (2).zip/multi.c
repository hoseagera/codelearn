#include <stdio.h>
int main()
{
int a = 5;
int b = 4;
int c = a*b;
printf("%d is the result of multiplying %d and %d",c,a,b);
return 0;
}