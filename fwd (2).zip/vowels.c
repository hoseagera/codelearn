#include <stdio.h>
int main()
{
char x;
printf("Enter a letter - ");
scanf("%c",&x);
if(x =='a' )
{
    printf("The letter you have entered is a vowel");
}
else if(x == 'e' )
{
    printf("The letter you have entered is a vowel");
}
else if(x == 'i' )
{
    printf("The letter you have entered is a vowel");
}
else if(x == 'o' )
{
    printf("The letter you have entered is a vowel");
}
else if(x == 'u' )
{
    printf("The letter you have entered is a vowel");
}
else
{
    printf("The letter you have entered is a consonant");
}
return 0;
}