#include <stdio.h>
int main ()
{
printf("jesus is my lord and savior");
return 0;
}
