#include <stdio.h>
int main()
{
int a;
printf("\n Enter a number");
scanf("%d",&a);
if(a<=10)
{
printf("\n The number you have entered is less than 10");
}
else
{
printf("\n The number you have entered is greater than 10");
}
return 0;
