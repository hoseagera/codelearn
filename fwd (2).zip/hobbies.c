#include <stdio.h>
int main ()
{
    printf("\n 1.cricket \n 2.games \n 3.football");
    return 0;
}